========
EC2 Spot
========

Assign jobs for ec2 spot instances using python.


Start an instance
=================


Stop an instance
================


Status of instances
===================
